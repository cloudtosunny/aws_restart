python -version

